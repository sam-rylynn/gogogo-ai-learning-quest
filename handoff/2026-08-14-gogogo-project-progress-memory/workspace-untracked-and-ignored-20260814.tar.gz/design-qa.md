# GOGO GO Pixel Guild Design QA

## Comparison target

- Source visual truth: `/Users/hao/.codex/generated_images/019f9971-1721-7cb0-96a1-7e7067d639dc/call_OdnOOoAz59xxGEkNuVAbYGOK.png`
- Rendered implementation: `/Users/hao/Claude/Artifacts/gogogo-ai-coach-review/qa-desktop-final2-1440x1024.png`
- Full-view comparison: `/private/tmp/gogogo-option2-vs-implementation-final.png`
- Focused quest-board comparison: `/private/tmp/gogogo-quest-focused-comparison-final.png`
- Desktop viewport: `1440 x 1024` CSS pixels
- Mobile viewport: `390 x 844` CSS pixels
- Tablet viewport: `1024 x 768` CSS pixels
- Source pixels: `1536 x 1024`
- Implementation capture pixels: `1440 x 1024`
- Density normalization: source was center-cropped to `1440 x 1024`; the implementation capture pixel dimensions matched its CSS viewport with no additional density scaling.
- Compared state: level 1, one of four evidence gates recorded, question queue empty.

## Full-view comparison evidence

The implementation preserves the selected direction's two-floor side-scrolling guild, mature navy/amber/wood palette, learner avatar, spatial station navigation, top HUD, central parchment mission, mentor prompt, keyboard controls, and bottom location strip. Live HTML replaces the mock's static labels so XP, evidence, streak, questions, mission, study mode, and gate state remain truthful.

## Focused comparison evidence

The focused quest-board comparison confirms the parchment frame, lanterns, dark Chinese hierarchy, four-gate route, artifact summary, unresolved-question count, and one dominant red primary action. The implementation adds the required 25/60/90-minute modes while retaining the source hierarchy.

## Findings

- No actionable P0, P1, or P2 findings remain.
- P3: HUD iconography is simpler than the concept image because live text controls are used instead of decorative static icons.
- P3: The live quest board uses rectangular evidence cells instead of the concept's circular stamp slots so four Chinese labels remain readable at mobile width.

## Required fidelity surfaces

- Fonts and typography: Chinese hierarchy is readable at desktop, tablet, and mobile sizes; mobile title clipping was corrected. Bitmap-style fallbacks preserve the game tone.
- Spacing and layout rhythm: mission panel, station labels, HUD, controls, and location strip remain inside all tested viewports without document overflow.
- Colors and visual tokens: ink navy, oxblood, amber, parchment, slate, green, and alert red match the selected concept.
- Image quality and asset fidelity: the generated guild scene, parchment board, and avatar are sharp raster assets rendered with pixelated image treatment; no placeholder illustrations are present.
- Copy and content: mission, evidence gates, hard failures, artifacts, study modes, and Codex responsibility boundaries are coherent and task-specific.
- Accessibility: semantic buttons and labels are present, focus rings are visible, keyboard `A/D/E` controls work, disabled retest controls are exposed, and reduced-motion mode is supported.

## Primary interactions tested

- Root URL redirects directly into the training page.
- Main "开始实战" action opens the evidence workflow.
- Closed-book evidence can be saved and updates the evidence HUD.
- Three-level workshop opens and the correct concept answer is accepted.
- Question queue supports add and remove.
- Rapid drawer switching no longer loses the newly opened panel.
- Course library opens the preserved original course content.
- Keyboard `A/D` movement and `E` interaction work.
- Console warnings/errors were empty during the final desktop, tablet, mobile, and interaction passes.

## Comparison history

1. Initial desktop capture found a low-contrast, compressed mission panel. Fixed by using the generated parchment asset, stronger text surfaces, and larger spacing.
2. Initial mobile capture found a crowded title. Fixed with a tighter mobile HUD grid, smaller avatar, and optical title sizing.
3. Mobile navigation inherited a generic transform and rendered off-screen. Fixed by explicitly resetting the location strip transform.
4. Rapidly closing one drawer and opening another exposed a stale close-timer race. Fixed by cancelling the stale timer and disabling pointer capture during close.
5. Final side-by-side comparison found the quest board too large and the primary action misaligned. Fixed by matching the source proportions, centering the primary action, and adding the unresolved-question count.

## Follow-up polish

- Optional P3: generate a dedicated evidence-stamp sprite sheet if circular seals are preferred over the current readable text cells.
- Optional P3: add subtle sound effects behind an explicit sound toggle.

final result: passed

## 2026-07-27 首屏像素文字系统复核

- 修改范围：仅首屏 HUD、场景路牌、任务板、模式按钮、关卡门、操作提示和底部地点栏；未修改课程结构、学习进度和交互逻辑。
- 字体资源：Fusion Pixel Font 12px proportional zh_hans，随项目本地加载；OFL 许可证保存在 `assets/fonts/LICENSE-OFL.txt`。
- 桌面复核：`qa-typography-desktop-final-1440x1024.png`，像素字体加载成功，路牌不再回退系统黑体，任务板无裁切。
- 移动复核：`qa-typography-mobile-final-390x844.png`，标题、任务板、四道证据门和底部地点栏无溢出或遮挡。
- 同尺寸对照：`/private/tmp/gogogo-typography-before-after.png`，改后弱化网页排版感，统一像素字形、硬边描边、数值层级与按压反馈。
- 控制台：0 个 warning，0 个 error。
- 最终结果：passed。

---

## 2026-08-04 主页当前关卡背景板收缩复核

### Comparison target

- Source visual truth: `/var/folders/fb/kpw7jwwx31103b5ywbpljjnc0000gn/T/codex-clipboard-9f7451a6-b5c8-4778-8626-3428c194fbbe.png`
- Browser-rendered implementation: `/tmp/gogogo-home-board-final-stage-968x610.png`
- Full-view comparison: `/tmp/gogogo-home-board-comparison-final-full.png`
- Focused quest-board comparison: `/tmp/gogogo-home-board-comparison-final-focus.png`
- Source pixels: `1936 x 1220`; normalized to `968 x 610` for the Retina-density comparison.
- Implementation viewport: `968 x 686` CSS pixels, DPR `1`; the compared stage region is `968 x 610` after removing the 76px HUD.
- Additional responsive viewports: `1440 x 1024`, `390 x 844`, and `320 x 568` CSS pixels.
- Compared state: Level 1, current step 01, next-level preview visible, main action `继续书库 0/8`.

### Full-view comparison evidence

The normalized annotation target is approximately `x=321–653, y=134–402`. The final board is `x=322–646, y=139–398`, so its outer edge stays inside the marked safe area with a 1–7px inset. Its center is `50% / 44%` of the stage, matching the annotation center, and the foreground actor remains above the board.

### Focused comparison evidence

The focused side-by-side comparison confirms that the parchment background no longer extends beyond the red target. Current level, current step, next-level preview, and the single action remain readable without restoring the removed STEP 01–05 list.

### Findings

- No actionable P0, P1, or P2 findings remain for the scoped quest-board change.
- No horizontal or vertical board overflow at `1440 x 1024`, `968 x 686`, `390 x 844`, or `320 x 568`.

### Required fidelity surfaces

- Fonts and typography: existing pixel font, hierarchy, wrapping, and weights are unchanged; all required board copy remains visible.
- Spacing and layout rhythm: the board is `324 x 259.2` at normal widths and `296 x 236.8` at 320px width; it stays centered and fully inside the stage.
- Colors and visual tokens: parchment, ink, navy current-step strip, oxblood action, borders, and shadows are unchanged.
- Image quality and asset fidelity: the existing guild-hall and foreground-actor raster assets remain unchanged; no replacement or placeholder asset was introduced.
- Copy and content: current level, current step, next-level preview, and main action are unchanged.

### Primary interactions tested

- Main `继续书库 0/8` action opens the course library and the drawer closes normally.
- Keyboard ArrowRight changes the camera position while the unified current-step and next-level components remain present.
- Fresh final browser run reported zero console warnings and zero console errors.

### Comparison history

1. Initial annotated screenshot: board measured about `1182 x 610` physical pixels, while the red safe area measured about `652 x 525`; the board was too wide and left-shifted.
2. Fixed the late CSS override that had re-expanded the earlier small-card design, reset the conflicting mobile `top`/`bottom` constraints, and constrained the board to the annotated `1.25:1` envelope.
3. Browser regression exposed an existing null HUD-counter write during keyboard movement. Added a null-safe update, then repeated responsive, interaction, and console checks successfully.

### Open questions

- Foreground actor mask calibration across every camera position remains a separate existing visual-risk item; this scoped change did not alter its geometry.

final result: passed

---

## 2026-08-04 主页当前关卡板移除复核

### Comparison target

- Source visual truth: `/var/folders/fb/kpw7jwwx31103b5ywbpljjnc0000gn/T/codex-clipboard-7b3a699c-fd53-4f21-991a-7165f399cc87.png`
- Browser-rendered implementation: `/tmp/gogogo-home-board-removed-744x560.png`
- Full-view desktop capture: `/tmp/gogogo-home-board-removed-968x686.png`
- Mobile capture: `/tmp/gogogo-home-board-removed-390x844.png`
- Side-by-side comparison: `/tmp/gogogo-home-board-removal-comparison.png`
- Source pixels: `744 x 560`; this is a cropped stage reference used to identify the exact board to remove.
- Implementation comparison viewport: `744 x 560` CSS pixels, DPR `1`; additional checks used `968 x 686`, `390 x 844`, and `320 x 568` CSS pixels.
- Compared state: Level 1 homepage; the current-level board is absent while the guild scene and navigation remain.

### Full-view comparison evidence

The final desktop and mobile captures show the original pixel-guild scene without the parchment current-level overlay. The underlying central wall, foreground characters, HUD, six station routes, and bottom location strip remain visible. The removed absolute-positioned panel leaves no layout gap and no document-width overflow.

### Focused comparison evidence

The combined source/result image shows the targeted bordered parchment, current-level title, current-step strip, next-level preview, and red action button present only in the source. In the implementation, `.pg-quest` computes to `display: none` with a `0 x 0` rectangle; its internal button is not visible, and hit testing at the former panel center reaches `.pg-scene` rather than the hidden panel.

### Findings

- No actionable P0, P1, or P2 findings remain for the scoped removal.
- No transparent click target, keyboard focus target, accessibility-tree panel, or layout space remains.
- P3 observation: the foreground-actor raster slice is now visually redundant, but no seam or duplicate edge is visible in the tested desktop and mobile captures.

### Required fidelity surfaces

- Fonts and typography: all typography belonging to the removed panel is intentionally absent; HUD and navigation typography are unchanged.
- Spacing and layout rhythm: the panel's absolute layer is removed from rendering without shifting the scene; `scrollWidth` equals the viewport at all tested widths.
- Colors and visual tokens: the scene's navy, amber, wood, stone, and parchment-wall colors are unchanged.
- Image quality and asset fidelity: the original guild-hall and foreground-character assets remain sharp and aligned; no new or replacement asset was introduced.
- Copy and content: only the current-level panel copy and its embedded CTA were removed; the six route labels and course entry remain available.

### Primary interactions tested

- All six scene stations remain visible at desktop width.
- The mobile bottom navigation retains all six destinations and scrolls internally at `320px` without widening the page.
- `课程书库` still opens the unified learning window, and its close control returns to the homepage.
- Final browser run reported zero console warnings and zero console errors.

### Comparison history

1. Source inspection identified `.pg-quest` as the single targeted visual region.
2. Dependency review found that physically deleting its child nodes would break existing state synchronization. The panel was therefore removed from rendering, hit testing, focus navigation, and the accessibility tree while its hidden state nodes remain available to existing scripts.
3. Desktop and mobile browser captures confirmed the board is absent, the scene has no new gap or overflow, and the course route still works.

final result: passed

---

## 2026-08-04 首页路牌统一与原生任务板进度复核

### Comparison target

- Station source: `/var/folders/fb/kpw7jwwx31103b5ywbpljjnc0000gn/T/codex-clipboard-296eed73-4512-42f6-9408-b48742a90b50.png` (`1170 x 400`).
- Native-board source: `/var/folders/fb/kpw7jwwx31103b5ywbpljjnc0000gn/T/codex-clipboard-3f803f99-451c-46be-8baa-5cf322a05cd3.png` (`776 x 672`).
- Progress-button source: `/var/folders/fb/kpw7jwwx31103b5ywbpljjnc0000gn/T/codex-clipboard-7de9d53d-dd27-4f1f-b154-e360635acebe.png` (`622 x 196`).
- Browser-rendered desktop implementation: `/tmp/gogogo-board-progress-final-1170x800.png` (`1170 x 800`, DPR `1`).
- Browser-rendered mobile implementation: `/tmp/gogogo-board-progress-final-390x844.png` (`390 x 844`, DPR `1`).
- Combined normalized comparison: `/tmp/gogogo-board-progress-comparison.png`.
- Additional narrow viewport: `320 x 568` CSS pixels.
- Compared state: Level 1, active route 3, latest progress `继续书库 0/8`.

### Full-view comparison evidence

The six desktop station plaques now share the Course Library standard: identical navy background, gold border, warm light text, opacity, shadow, vertical offset, and no pulse animation. The longer `项目作品陈列门` retains automatic width so its label remains on one line; height and all visual tokens remain identical to the other five plaques.

The hall's existing central parchment is still the only board surface. The implementation adds only `GOGOGO` and the live progress control; the overlay container computes to a transparent background, no background image, zero border, zero outline, and no box shadow.

### Focused comparison evidence

The native asset's conservative content box is `x=653–950, y=418–619` in the `1586 x 992` source. The live content container maps to that box within about one CSS pixel at `1170 x 800`, `390 x 844`, and every tested camera offset. The title occupies the upper safe region and the button occupies the lower safe region without touching the parchment frame or the foreground actor.

The button comparison confirms the oxblood fill, dark outer border, warm inset line, offset dark shadow, cream pixel text, and current `0/8` progress match the supplied visual direction.

### Findings

- No actionable P0, P1, or P2 findings remain.
- No panel, mask, tint, gradient, replacement board image, or additional backdrop was introduced.
- P3 accepted constraint: `项目作品陈列门` is wider than the five shorter plaques so the approved label remains readable without wrapping.

### Required fidelity surfaces

- Fonts and typography: all six plaques use the same pixel font, weight, size, line height, letter spacing, color, and shadow; `GOGOGO` and the live progress label retain readable pixel rendering across breakpoints.
- Spacing and layout rhythm: board content uses the measured `297 x 201` safe-box ratio; title and button stay in their designated upper/lower regions. Page `scrollWidth` equals viewport width at every tested breakpoint.
- Colors and visual tokens: plaques share the Course Library navy/gold treatment; the progress action reuses the existing oxblood/cream/gold button treatment.
- Image quality and asset fidelity: `pixel-guild-hall.png` is unchanged and remains the only board/background image. Foreground actors stay above the content without visible seams.
- Copy and content: the board title is exactly `GOGOGO`; the button displays the calculated latest step, currently `继续书库 0/8`.

### Primary interactions tested

- The live progress button opens the Course Library and the close control returns to the homepage.
- All six `A/D` camera positions were traversed and restored; the task content stayed within the native board safe box at every position.
- Mobile retains all six bottom-navigation destinations; the desktop scene plaques remain hidden below the existing `760px` breakpoint.
- Final browser run reported zero console warnings and zero console errors.

### Comparison history

1. Initial desktop implementation matched the measured task-board bounds and unified all six plaque styles.
2. The first `320 x 568` pass found the progress label's content width 11px larger than its button client width, a P2 narrow-screen readability issue.
3. Narrow-screen horizontal padding and letter spacing were tightened; the repeated `320 x 568` pass showed the complete `继续书库 0/8` label, contained button geometry, and no document overflow.

final result: passed
